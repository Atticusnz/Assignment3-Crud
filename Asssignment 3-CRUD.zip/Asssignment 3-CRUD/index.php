<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SCP CRUD Application</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
  </head>
  <body class="container">
      <?php include 'connection.php'; ?>
      <!-- Database driven Menu -->
      <div>
          <ul class="nav navbar-dark bg-dark">
              <!-- php loop thru scp table and display the item field only -->
              <?php foreach($result as $menu_item): ?>
                <li class="nav-item active"><a href="index.php?link='<?php echo $menu_item['item']; ?>'" class="nav-link text-light"><?php echo $menu_item['item']; ?></a></li>
              <?php endforeach; ?>
              <li class="nav-item active"><a href="form.php" class="nav-link text-light">Add a new SCP</a></li>
          </ul>
      </div>
      
      <div class="row">
          <div class="col-12 bg-light rounded shadow p-3">
            <h1>Welcome to the SCP CRUD Application</h1>
            
            <?php
            
                if(isset($_GET['link']))
                {
                    $link = trim($_GET['link'], "'");
                    
                    // run sql to retreive record based on $link
                    $record = $connection->query("select * from scp where item='$link'");
                    
                    // turn $record into associative array
                    $array = $record->fetch_assoc();
                    
                    //variables to hold our update and delte url strings
                    $id = $array['id'];
                    $update = "update.php?update=" . $id;
                    $delete = "connection.php?delete=" . $id;
                    
                    echo "
                    <style>
                    {
                        
                    }
                    </style>
                    
                        <p>{$array['item']}</p>
                        <p>{$array['object']}</p>
                        <p>{$array['description']}</p>
                        <p>{$array['containment']}</p>
                    
                    
                    <p>
                    
                    <a href='{$update}' class='btn btn-warning'>Update Record</a>
                    <a href='{$delete}' class='btn btn-danger'>Delete Record</a>
                    
                    </p>
                    
                    <p><a href='index.php' class='btn btn-primary'>return to main</a></p>
                    
                     ";
                    
                    
                }
                else
                {
                    //First time accessing the website
                    echo "
                    <h2>Welcome to this database driven website</h2>
                    <center><p>Please use the links above.</p>
                    <p><img src='images/scp 1000 bigfoot_patterson01-new.png'></p></center>
                    ";
                }
            
            ?>
            
            
          </div>
      </div>
 
        
        
    

    
    
    <style>
       
       *
        {
           margin:0;
           Padding:0;
           box-sizing:border-box;
           font-family:verdana;
        }
        
        body
        {
        background-image: linear-gradient(to bottom left, rgb(0, 0, 0), Silver);
        color: Black;
        min-height: 100vh;
        }
        
        
    </style>
    
    
    
    
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
 
 
 
  </body>
</html>
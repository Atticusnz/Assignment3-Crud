<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
  </head>
  <body class="container">
      <br><br><br><br>
      
    <h1>Assignment 3</h1>
    <p>Formpage</p>
    <h2>Form</h2>
    <p>Return to index page</p>
    <p><a href="index.php" class="btn btn-primary"> Index page</a></p>
    <?php

    include "connection.php";

    $id = $_GET['update'];
    $record = $connection->query("select * from scp where id=$id");
    $row = $record->fetch_assoc();
    ?>

    
    <form method="post" action="connection.php" class="form-group">
        
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>"
        
        <label>Enter Item</label>
        <br>
        <input type="text" name="item" placeholder="Item" class="form-control" value="<?php echo $row['item']; ?>">
        <br><br>
        
        <label>Enter Object</label>
        <br>
        <input type="text" name="object" placeholder="Object" class="form-control" value="<?php echo $row['object']; ?>">
        <br><br>
        
        <label>Enter Containment</label>
        <br>
        <input type="text" name="containment" placeholder="Containment" class="form-control" value="<?php echo $row['containment']; ?>">
        <br><br>
        
        <label>Enter description</label>
        <br>
        <input type="text" name="description" placeholder="Description" class="form-control" value="<?php echo $row['description']; ?>">
        <br><br>
        
        
        <label>Enter image location</label>
        <br>
        <input type="text" name="image" placeholder="images/nameofimage.jpg or similar" class="form-control" value="<?php echo $row['image']; ?>"> 
        <br><br>
        
        
        <input type="submit" name="update" value="Update record" class="btn btn-dark">
        
    </form>
    
    <style>
        
        body
        {
        background-image: linear-gradient(to bottom left, rgb(0, 0, 0), Silver);
        color: Black;
        min-height: 100vh;
        }
        
    </style>
    
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
 
 
 
  </body>
</html>
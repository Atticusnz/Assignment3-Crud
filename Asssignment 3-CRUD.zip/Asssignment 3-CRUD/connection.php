<?php
    

    
    //Database connection
    $connection = new mysqli('localhost' , $user, $pw, $db);
    
    //variable thjat returns all records in database
    $result = $connection->query("select * from scp");
    
    //check if  form data has been send via post
    if(isset($_POST['submit']))
    {
        //create variables from our form post data
        //"mysqli_real_escape_string" allows speceal char
        $item = mysqli_real_escape_string($connection, $_POST['item']);
        $object = mysqli_real_escape_string($connection,$_POST['object']);
        $containment = mysqli_real_escape_string($connection,$_POST['containment']);
        $description = mysqli_real_escape_string($connection,$_POST['description']);
        $image = mysqli_real_escape_string($connection,$_POST['image']);
        
        $insert = "insert into scp(item, object, containment, description, image)
        values('$item', '$object', '$containment', '$description', '$image')";
        
        if($connection->query($insert) === TRUE)
        {
            echo "
                <style>
                    body{font-family: sans-serif}
                    a {
                        background-color: black;
                        border: none;
                        color: white;
                        padding: 15px 32px;
                        text-align: center;
                        text-decoration: none;
                        display: inline-block;
                        font-size: 16px;
                    }
                </style>
                <h1>Record added succesfully</h1>
                <p><a href='index.php'>Return to index page</a></p>";
        }
        else
        {
             echo"
             <style>
                    body{font-family: sans-serif}
                    a {
                        background-color: red;
                        border: none;
                        color: white;
                        padding: 15px 32px;
                        text-align: center;
                        text-decoration: none;
                        display: inline-block;
                        font-size: 16px;
                    }
                </style>
                <h1>Error submitting data</h1>
                <p>{$connection->error}</p>
                <p><a href='form.php'>Return to form</a></p>
             
             ";
        }
    } // end insert
    
    
    
    if(isset($_POST['update']))
    {
        //create variables from our form post data
        //"mysqli_real_escape_string" allows speceal char
        $id = mysqli_real_escape_string($connection, $_POST['id']);
        $item = mysqli_real_escape_string($connection, $_POST['item']);
        $object = mysqli_real_escape_string($connection,$_POST['object']);
        $containment = mysqli_real_escape_string($connection,$_POST['containment']);
        $description = mysqli_real_escape_string($connection,$_POST['description']);
        $image = mysqli_real_escape_string($connection,$_POST['image']);
        
        
        $update = "update scp set item='$item', object='$object', containment='$containment', description='$description',image='$image' where id='$id'";
        
        if($connection->query($update) === TRUE)
        {
            echo "
                <style>
                    body{font-family: sans-serif}
                    a {
                        background-color: black;
                        border: none;
                        color: white;
                        padding: 15px 32px;
                        text-align: center;
                        text-decoration: none;
                        display: inline-block;
                        font-size: 16px;
                    }
                </style>
                <h1>Record UpdaTed succesfully</h1>
                <p><a href='index.php'>Return to index page</a></p>";
        }
        else
        {
             echo"
             <style>
                    body{font-family: sans-serif}
                    a {
                        background-color: blue;
                        border: none;
                        color: white;
                        padding: 15px 32px;
                        text-align: center;
                        text-decoration: none;
                        display: inline-block;
                        font-size: 16px;
                    }
                </style>
                <h1>ErrOr UPdating</h1>
                <p>{$connection->error}</p>
                <p><a href='form.php'>Return to form</a></p>
             
             ";
        }
    }
    
    
    
    if(isset($_GET['delete']))
    {
        $id = $_GET['delete'];
        $del = "delete from scp where id=$id";
        
        if($connection->query($del) === TRUE)
        {
            echo "
                <style>
                    body{font-family: sans-serif}
                    a {
                        background-color: black;
                        border: none;
                        color: white;
                        padding: 15px 32px;
                        text-align: center;
                        text-decoration: none;
                        display: inline-block;
                        font-size: 16px;
                    }
                </style>
                <h1>Record Deleted</h1>
                <p><a href='index.php'>Return to index page</a></p>";
        }
        else
        {
             echo"
             <style>
                    body{font-family: sans-serif}
                    a {
                        background-color: blue;
                        border: none;
                        color: white;
                        padding: 15px 32px;
                        text-align: center;
                        text-decoration: none;
                        display: inline-block;
                        font-size: 16px;
                    }
                </style>
                <h1>Error deleting</h1>
                <p>{$connection->error}</p>
                <p><a href='form.php'>Return to form</a></p>
             
             ";
        }
    }
    
    
    
    ?>